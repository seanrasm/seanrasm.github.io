//Web Storage

/* This is pseudo code declaring variables

    var sean = localStorageSelector
    var key = inputID
    var input = StoredValue
    var s = VariableToDisplayLocalStorageInList
    var n = slideShowNumber
    var i = indexOfSlideShow


*/

(function() {

	var sean = document.querySelector('.localstorage');

	function supportsLocalStorage() {
		return typeof(Storage)!== 'undefined';
	}

	if (!supportsLocalStorage()) {
		sean.value = 'Your browser does not support localStorage.';
	} else {
		try {
			setInterval(function() {
				localStorage.setItem('autosave', sean.value);
			}, 1000);
		} catch (e) {
			if (e == QUOTA_EXCEEDED_ERR) {
				alert('Quota exceeded!');
			}
		}
		if (localStorage.getItem('autosave')) {
			sean.value = localStorage.getItem('autosave');
		}
		document.querySelector('.clear').onclick = function() {
			sean.value = '';
			localStorage.removeItem('autosave');
		};
		document.querySelector('.empty').onclick = function() {
			sean.value = '';
			localStorage.clear();
		};
	}

})();

var inputTest= document.getElementById("storeList");
localStorage.setItem("storeList", inputTest.value);

function persistInput(input)
{
  var key = "input-" + input.id;

  var storedValue = localStorage.getItem(key);

  if (storedValue)
      input.value = storedValue;

  input.addEventListener('input', function ()
  {
      localStorage.setItem(key, input.value);
  });
}


document.addEventListener("click", presentList);

function presentList() {
	  var s = localStorage.getItem("storeList");
    document.getElementById("present").innerHTML = s;
}



localStorage.setItem("firstFav", "Taco");
localStorage.setItem("secondFav", "Pizza");
localStorage.setItem("thirdFav", "Fruit Roll Up");
// Retrieve
document.getElementById("firstFav").innerHTML = localStorage.getItem("firstFav");
document.getElementById("secondFav").innerHTML = localStorage.getItem("secondFav");
document.getElementById("thirdFav").innerHTML = localStorage.getItem("thirdFav");


//Beginning of slide show on home page

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}

//Drop Down Functionality 
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}